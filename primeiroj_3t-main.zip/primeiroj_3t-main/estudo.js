console.log("Console: Alô Mundo...");
alert("Alerta: Alô mundo...");